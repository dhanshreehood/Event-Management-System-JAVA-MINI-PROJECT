package com.cybage.service;

import java.util.List;

import com.cybage.bean.Category;
import com.cybage.dao.CategoryDAO;
import com.cybage.dao.CategoryDAOImp;


public class CategoryServiceImp implements CategoryService {
	
	private CategoryDAO categoryDao=new CategoryDAOImp();

	@Override
	public boolean add(Category category) {
		return categoryDao.add(category);
	}

	@Override
	public Category getCategoryById(int categoryId) {
		
		return categoryDao.getCategoryById(categoryId);
	}

	@Override
	public List<Category> getAllCategory() {
		return categoryDao.getAllCategory();
	}

	@Override
	public boolean deleteCategory(int categoryId) {
		return categoryDao.deleteCategory(categoryId);
	}

	@Override
	public boolean updateCategory(Category category) {
		return categoryDao.updateCategory(category);
	}

	

}
