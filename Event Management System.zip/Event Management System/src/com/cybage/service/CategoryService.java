package com.cybage.service;

import java.util.List;

import com.cybage.bean.Category;

public interface CategoryService {

	public boolean add(Category category);
	public Category getCategoryById(int categoryId);
	public List<Category> getAllCategory();
	public boolean deleteCategory(int categoryId);
	public boolean updateCategory(Category category);
	
}
