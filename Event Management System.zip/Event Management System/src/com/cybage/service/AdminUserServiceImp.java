package com.cybage.service;

import java.util.List;

import com.cybage.bean.AdminUser;
import com.cybage.dao.AdminUserDAO;
import com.cybage.dao.AdminUserDAOImp;


public class AdminUserServiceImp implements AdminUserService {
	
	private AdminUserDAO adminUserDao = new AdminUserDAOImp();

	@Override
	public List<AdminUser> getAllAdminUser() {
		return adminUserDao.getAllAdminUser();
	}
}
