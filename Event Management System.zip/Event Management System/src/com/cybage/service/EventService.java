package com.cybage.service;

import java.util.List;

import com.cybage.bean.BookingEvent;
import com.cybage.bean.Event;
import com.cybage.bean.User;

public interface EventService {

	public boolean add(Event event);
	public Event getEventById(int eventId);
	public List<Event> getAllEvent();
	public boolean EventDelete(int eventId);
	public boolean EventEdit(Event event);
	public String authenticateUser(User user);
	public boolean addBookedEvent(BookingEvent bookingEvent);
	public List<BookingEvent> getAllBookedEvent();
	public boolean deleteBookedEvent(int bookingId);

}
