package com.cybage.service;

import java.util.List;

import com.cybage.bean.AdminUser;

public interface AdminUserService {

	public List<AdminUser> getAllAdminUser();

}
