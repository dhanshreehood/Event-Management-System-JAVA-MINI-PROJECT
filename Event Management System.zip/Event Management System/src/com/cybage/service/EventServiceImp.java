package com.cybage.service;

import java.util.List;

import com.cybage.bean.BookingEvent;
import com.cybage.bean.Event;
import com.cybage.bean.User;
import com.cybage.dao.Eventdao;
import com.cybage.dao.EventdaoImp;

public class EventServiceImp implements EventService {

	private Eventdao eventdao = new EventdaoImp();

	@Override
	public boolean add(Event event) {
		
		return eventdao.add(event);
	}

	@Override
	public Event getEventById(int eventId) {
		
		return eventdao.getEventById(eventId);
	}

	@Override
	public List<Event> getAllEvent() {
		
		return eventdao.getAllEvent() ;
	}

	@Override
	public boolean EventDelete(int eventId) {
		
		return eventdao.EventDelete(eventId);
	}

	@Override
	public boolean EventEdit(Event event) {
		
		return eventdao.EventEdit(event) ;
	}

	@Override
	public String authenticateUser(User user) {
		return eventdao.authenticateUser(user);
	}

	@Override
	public boolean addBookedEvent(BookingEvent bookingEvent) {
		
		return eventdao.addBookedEvent(bookingEvent);

	}

	@Override
	public List<BookingEvent> getAllBookedEvent() {
		
		return eventdao.getAllBookedEvent();
	}

	@Override
	public boolean deleteBookedEvent(int bookingId) {
		return eventdao.deleteBookedEvent(bookingId);
	}
	
}
