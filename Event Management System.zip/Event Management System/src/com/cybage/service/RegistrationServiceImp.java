package com.cybage.service;

import java.util.List;

import com.cybage.bean.Registration;
import com.cybage.dao.RegistrationDAO;
import com.cybage.dao.RegistrationDAOImp;

public class RegistrationServiceImp implements RegistrationService {

	RegistrationDAO registrationDao = new RegistrationDAOImp();
	
	@Override
	public boolean addUser(Registration registration) {
		
		return registrationDao.addUser(registration);
	}

	@Override
	public Registration userLogin(Registration registration) {
		
		return registrationDao.userLogin(registration);
	}

	@Override
	public List<Registration> getAllUsers() {
		
		return registrationDao.getAllUsers();
	}

}
