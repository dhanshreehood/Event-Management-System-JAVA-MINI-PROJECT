package com.cybage.service;

import java.util.List;

import com.cybage.bean.User;
import com.cybage.dao.AdminOrganizerDAO;
import com.cybage.dao.AdminOrganizerDAOImp;


public class AdminOrganizerServiceImp implements AdminOrganizerService{

	private AdminOrganizerDAO adminOrganizerDao = new AdminOrganizerDAOImp();
	
	@Override
	public List<User> getAllAdminOrganizer() {
		return adminOrganizerDao.getAllAdminOrganizer();
	}

	
	
	
}
