package com.cybage.service;

import java.util.List;

import com.cybage.bean.Registration;

public interface RegistrationService {

	public boolean addUser(Registration registration);
	public Registration userLogin(Registration registration);
	public List<Registration>getAllUsers();	
	
}
