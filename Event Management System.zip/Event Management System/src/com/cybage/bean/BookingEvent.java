package com.cybage.bean;

public class BookingEvent {
	
	private int bookingId;
	private String bookingAddress;
	private String totalPeople;
	private String bookingDate;
	
	
	public BookingEvent() {
		
		
	}
	
	public BookingEvent(int bookingId, String bookingAddress, String totalPeople, String bookinDate) {
		super();
		this.bookingId = bookingId;
		this.bookingAddress = bookingAddress;
		this.totalPeople = totalPeople;
		this.bookingDate = bookinDate;
	}

	public int getBookingId() {
		return bookingId;
	}
	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}
	public String getBookingAddress() {
		return bookingAddress;
	}
	public void setBookingAddress(String bookingAddress) {
		this.bookingAddress = bookingAddress;
	}
	public String getTotalPeople() {
		return totalPeople;
	}
	public void setTotalPeople(String totalPeople) {
		this.totalPeople = totalPeople;
	}
	public String getBookingDate() {
		return bookingDate;
	}
	public void setBookingDate(String bookingDate) {
		this.bookingDate = bookingDate;
	}
	
	
}