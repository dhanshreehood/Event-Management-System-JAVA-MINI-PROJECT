package com.cybage.bean;

public class AdminUser {
	
	private int uid;
	private String username;
	private String uemail;
	private String upassword;
	private String uaddress;
	private String ucontact;
	
	public AdminUser()
	{
		
	}

	public AdminUser(int uid, String username, String uemail, String upassword, String uaddress, String ucontact) {
		super();
		this.uid = uid;
		this.username = username;
		this.uemail = uemail;
		this.upassword = upassword;
		this.uaddress = uaddress;
		this.ucontact = ucontact;
	}

	public int getUid() {
		return uid;
	}

	public void setUid(int uid) {
		this.uid = uid;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getUemail() {
		return uemail;
	}

	public void setUemail(String uemail) {
		this.uemail = uemail;
	}

	public String getUpassword() {
		return upassword;
	}

	public void setUpassword(String upassword) {
		this.upassword = upassword;
	}

	public String getUaddress() {
		return uaddress;
	}

	public void setUaddress(String uaddress) {
		this.uaddress = uaddress;
	}

	public String getUcontact() {
		return ucontact;
	}

	public void setUcontact(String ucontact) {
		this.ucontact = ucontact;
	}

}
