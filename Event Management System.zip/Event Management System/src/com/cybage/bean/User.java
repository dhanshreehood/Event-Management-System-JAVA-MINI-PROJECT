package com.cybage.bean;

public class User {
	private int uid;
	private String ufname;
	private String ulname;
	private String username;
	private String uemail;
	private String upassword;
	private String uaddress;
	private String ucontact;
	private String role;

	//default contructor
	public User() {
		
	}

	public User(int uid, String ufname, String ulname, String username, String uemail, String upassword,
			String uaddress, String ucontact, String role) {
		super();
		this.uid = uid;
		this.ufname = ufname;
		this.ulname = ulname;
		this.username = username;
		this.uemail = uemail;
		this.upassword = upassword;
		this.uaddress = uaddress;
		this.ucontact = ucontact;
		this.role = role;
	}



	public int getUid() {
		return uid;
	}

	public void setUid(int uid) {
		this.uid = uid;
	}

	public String getUfname() {
		return ufname;
	}

	public void setUfname(String ufname) {
		this.ufname = ufname;
	}

	public String getUlname() {
		return ulname;
	}

	public void setUlname(String ulname) {
		this.ulname = ulname;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getUemail() {
		return uemail;
	}

	public void setUemail(String uemail) {
		this.uemail = uemail;
	}

	public String getUpassword() {
		return upassword;
	}

	public void setUpassword(String upassword) {
		this.upassword = upassword;
	}

	public String getUaddress() {
		return uaddress;
	}

	public void setUaddress(String uaddress) {
		this.uaddress = uaddress;
	}

	public String getUcontact() {
		return ucontact;
	}

	public void setUcontact(String ucontact) {
		this.ucontact = ucontact;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}


}
