package com.cybage.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cybage.service.EventService;
import com.cybage.service.EventServiceImp;

/**
 * Servlet implementation class DeleteBookedEventServlet
 */
@WebServlet("/DeleteBookedEventServlet")
public class DeleteBookedEventServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	EventService eventService = new EventServiceImp();

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out =response.getWriter();
		int bookingId=(Integer.parseInt(request.getParameter("bookingId")));
		
		boolean flag = eventService.deleteBookedEvent(bookingId);
		if (flag) 
		{
			System.out.println("Record deleted successfully");
			out.println("Record deleted successfully");
			response.sendRedirect("BookEventServlet");
		} 
		else 
		{
			System.out.println("Error in code");
		}
	}

}
