package com.cybage.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cybage.bean.Category;
import com.cybage.controller.CategoryServlet;
import com.cybage.service.CategoryService;
import com.cybage.service.CategoryServiceImp;


@WebServlet("/EventCategoryServlet")
public class EventCategoryServlet extends HttpServlet {
	
	CategoryService categoryService = new CategoryServiceImp();
  
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		List<Category> categoryList = categoryService.getAllCategory();
		
		ServletContext context = getServletContext();
		
		context.setAttribute("categoryList", categoryList);
		RequestDispatcher dispatcher = request.getRequestDispatcher("index.jsp");
		dispatcher.forward(request, response);
		
		
	}
}
