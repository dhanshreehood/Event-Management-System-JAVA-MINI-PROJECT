package com.cybage.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cybage.bean.Registration;
import com.cybage.service.RegistrationService;
import com.cybage.service.RegistrationServiceImp;


@WebServlet("/RegistrationServlet")
public class RegistrationServlet extends HttpServlet {

	RegistrationService registrationService = new RegistrationServiceImp();
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		Registration registration = new Registration();
		
		registration.setUfname(request.getParameter("ufname"));
		registration.setUlname(request.getParameter("ulname"));
		registration.setUsername(request.getParameter("username"));
		registration.setUemail(request.getParameter("uemail"));
		registration.setUpassword(request.getParameter("upassword"));
		registration.setUaddress(request.getParameter("uaddress"));
		registration.setUcontact(request.getParameter("ucontact"));
		registration.setRole(request.getParameter("role"));
		
     	boolean flag = registrationService.addUser(registration);
//      String usernameValidate = eventService.checkUsernameExists(registerBean); //Calling authenticateUser function

		if (flag) {
			System.out.println("User Record inserted successfully");
			request.setAttribute("user", registration);
			RequestDispatcher dispatcher = request.getRequestDispatcher("UserLogin.jsp");
			dispatcher.forward(request, response);
		} 
		
		else {
			System.out.println("Record not inserted.");
			request.setAttribute("errMessage", flag); //If authenticateUser() function returns other than SUCCESS string it will be sent to Login page again. Here the error message returned from function has been stored in a errMessage key.
        request.getRequestDispatcher("UserRegistration.jsp").forward(request, response);//forwarding the request
		}
	}
}