package com.cybage.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cybage.service.CategoryService;
import com.cybage.service.CategoryServiceImp;

@WebServlet("/DeleteCategoryController")
public class DeleteCategoryController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	CategoryService categoryService = new CategoryServiceImp();
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out =response.getWriter();
		int categoryId=(Integer.parseInt(request.getParameter("categoryId")));
		
		boolean flag = categoryService.deleteCategory(categoryId);
		if (flag) 
		{
			System.out.println("Record deleted successfully");
			out.println("Record deleted successfully");
			response.sendRedirect("CategoryServlet");
		} 
		else 
		{
			System.out.println("Error in code");
		}
	}
}