package com.cybage.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cybage.bean.AdminUser;

@WebServlet("/AdminLoginServlet")
public class AdminLoginServlet extends HttpServlet {

	protected void dopost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			
			String adminusername = request.getParameter("Username");
			String adminpassword = request.getParameter("Password");
			HttpSession session = request.getSession();
			
		
			if("admin".equals(adminusername) && "admin123".equals(adminpassword))
			{
				//session.setAttribute("adminObj", new AdminUser());
				response.sendRedirect("adminDashboard.jsp");
			}
			else
			{
				//session.setAttribute("errorMessage", "Invalid Username and Password");
				response.sendRedirect("UserLogin.jsp");
			}
			}
			catch (Exception e) 
			{
				e.printStackTrace();
			}
}
}