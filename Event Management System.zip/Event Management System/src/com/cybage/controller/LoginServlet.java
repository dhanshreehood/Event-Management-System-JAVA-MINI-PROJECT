package com.cybage.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cybage.bean.User;
import com.cybage.service.EventService;
import com.cybage.service.EventServiceImp;


@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {

	EventService eventService = new EventServiceImp();
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//      user and event organizer
    	User user = new User(); //creating object for User class, which is a normal java class, contains just setters and getters. Bean classes are efficiently used in java to access user information wherever required in the application.
//      Here username and password are the names which I have given in the input box in Login.jsp page. Here I am retrieving the values entered by the user and keeping in instance variables for further use.
        String username = request.getParameter("username");
        String password = request.getParameter("upassword");
        String role = request.getParameter("role");
        
        user.setUsername(username); //setting the username and password through the user object then only you can get it in future.
        user.setUpassword(password);
        user.setRole(role);

      String userValidate = eventService.authenticateUser(user); //Calling authenticateUser function
      
      if(username.equals("admin") && password.equals("admin@123")) {      	
			HttpSession session = request.getSession();
			session.setAttribute("admin", username);
          request.setAttribute("admin", user); //with setAttribute() you can define a "key" and value pair so that you can get it in future using getAttribute("key")

          response.sendRedirect("adminDashboard.jsp");
      }       
      else if(userValidate.equals("EVENT_ORGANIZER")) //If function returns success and role is event organizer string then user will be rooted to Home page
       {    	
			 System.out.println("Event Organizer loggedIn successfully");
			 
			 HttpSession session = request.getSession();
			 session.setMaxInactiveInterval(10*60);
			 session.setAttribute("eventOrganizer", username);
			 
           request.setAttribute("eventOrganizer", username); //with setAttribute() you can define a "key" and value pair so that you can get it in future using getAttribute("key")
//         request.getRequestDispatcher("UserHome.jsp").forward(request, response);//RequestDispatcher is used to send the control to the invoked page.
           response.sendRedirect("organizerDashboard.jsp");
       }
       
      else if(userValidate.equals("USER")) //If function returns success string and role is user then user will be rooted to Home page
      {
			 System.out.println("User loggedIn successfully");
			 
			 HttpSession session = request.getSession();
			 session.setMaxInactiveInterval(10*60);
			 session.setAttribute("user", username);
			 
          request.setAttribute("user", username); //with setAttribute() you can define a "key" and value pair so that you can get it in future using getAttribute("key")
//        request.getRequestDispatcher("UserHome.jsp").forward(request, response);//RequestDispatcher is used to send the control to the invoked page.
          response.sendRedirect("userDashboard.jsp");
      }

       else
       {
           request.setAttribute("errMessage", userValidate); //If authenticateUser() function returns other than SUCCESS string it will be sent to Login page again. Here the error message returned from function has been stored in a errMessage key.
           request.getRequestDispatcher("UserLogin.jsp").forward(request, response);//forwarding the request
       }
  }
}

