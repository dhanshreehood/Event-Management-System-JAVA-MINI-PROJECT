package com.cybage.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cybage.service.EventService;
import com.cybage.service.EventServiceImp;


@WebServlet("/EventDelete")
public class EventDelete extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
     
	EventService eventService = new EventServiceImp();
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out =response.getWriter();
		int eventId=(Integer.parseInt(request.getParameter("eventId")));
		
		boolean flag = eventService.EventDelete(eventId);
		if (flag) {
			System.out.println("Record deleted successfully");
			out.println("Record deleted successfully");
			response.sendRedirect("EventServlet");
		} else {
			System.out.println("error in Delete");
		}
	}
}
