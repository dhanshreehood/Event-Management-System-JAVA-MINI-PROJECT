package com.cybage.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cybage.bean.Category;
import com.cybage.service.CategoryService;
import com.cybage.service.CategoryServiceImp;


@WebServlet("/CategoryServlet")
public class CategoryServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	CategoryService categoryService = new CategoryServiceImp();
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		List<Category> categoryList = categoryService.getAllCategory();
		request.setAttribute("categoryList", categoryList);
		RequestDispatcher dispatcher = request.getRequestDispatcher("viewEventCategory.jsp");
		dispatcher.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Category category = new Category();

//		category.setCategoryId(Integer.parseInt(request.getParameter("categoryId")));
		category.setCategoryName(request.getParameter("categoryName"));
		
		System.out.println(request.getParameter("categoryName"));

		boolean flag = categoryService.add(category);
		if (flag) 
		{
			System.out.println("Record instered successfully");
			response.sendRedirect("CategoryServlet");
		} 
		else 
		{
			System.out.println("Error in code");
		}
	}

}