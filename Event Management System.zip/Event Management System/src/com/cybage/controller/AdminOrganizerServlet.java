package com.cybage.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cybage.bean.User;
import com.cybage.service.AdminOrganizerService;
import com.cybage.service.AdminOrganizerServiceImp;

@WebServlet("/AdminOrganizerServlet")
public class AdminOrganizerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	AdminOrganizerService adminOrganizerService = new AdminOrganizerServiceImp();
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		List<User> adminOrganizerList = adminOrganizerService.getAllAdminOrganizer();
		request.setAttribute("adminOrganizerList", adminOrganizerList);
		RequestDispatcher dispatcher = request.getRequestDispatcher("viewAdminOrganizer.jsp");
		dispatcher.forward(request, response);
			
	}
}
