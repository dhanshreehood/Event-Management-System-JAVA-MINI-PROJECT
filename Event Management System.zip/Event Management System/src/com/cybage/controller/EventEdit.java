package com.cybage.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cybage.bean.Event;
import com.cybage.service.EventService;
import com.cybage.service.EventServiceImp;

@WebServlet("/EventEdit")
public class EventEdit extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	
	EventService eventService = new EventServiceImp();

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		int eventId=Integer.parseInt(request.getParameter("eventId"));
		PrintWriter out= response.getWriter();
		out.println(eventId);
		Event event=eventService.getEventById(eventId);
	
		request.setAttribute("eve", event);
		RequestDispatcher dispatcher = request.getRequestDispatcher("editEvent.jsp");
		dispatcher.forward(request, response);
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		Event event = new Event();
		
		event.setEventId(Integer.parseInt(request.getParameter("eventId")));
		event.setEventName(request.getParameter("eventName"));
		event.setEventCategory(request.getParameter("eventCategory"));
		event.setEventDescription(request.getParameter("eventDescription"));
		event.setEventPrice(request.getParameter("eventPrice"));
				
				boolean flag = eventService.EventEdit(event);
				if (flag) {
					System.out.println("Record edited successfully");
					
					response.sendRedirect("EventServlet");
				} else {
					System.out.println("error in Edit");
				}
			}

}
