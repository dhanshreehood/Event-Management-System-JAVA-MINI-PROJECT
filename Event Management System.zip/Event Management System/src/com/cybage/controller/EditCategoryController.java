package com.cybage.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cybage.bean.Category;
import com.cybage.service.CategoryService;
import com.cybage.service.CategoryServiceImp;

@WebServlet("/EditCategoryController")
public class EditCategoryController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	CategoryService categoryService = new CategoryServiceImp();
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		int catId=Integer.parseInt(request.getParameter("categoryId"));
		PrintWriter out= response.getWriter();
		out.println(catId);
		Category category = categoryService.getCategoryById(catId);
		request.setAttribute("cat", category);
		RequestDispatcher dispatcher = request.getRequestDispatcher("editCategory.jsp");
		dispatcher.forward(request, response);			
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		Category category = new Category();

		category.setCategoryId(Integer.parseInt(request.getParameter("categoryId")));
		category.setCategoryName(request.getParameter("categoryName"));
				
				boolean flag = categoryService.updateCategory(category);
				if (flag) {
					System.out.println("Record updated successfully");
					response.sendRedirect("CategoryServlet");
				} else {
					System.out.println("Error in code");
				}
			}

		}