package com.cybage.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cybage.bean.BookingEvent;
import com.cybage.bean.Category;
import com.cybage.bean.Event;
import com.cybage.service.EventService;
import com.cybage.service.EventServiceImp;

/**
 * Servlet implementation class BookEventServlet
 */
@WebServlet("/BookEventServlet")
public class BookEventServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	EventService eventService = new EventServiceImp();
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {	
		List<BookingEvent> bookedList = eventService.getAllBookedEvent();
		request.setAttribute("bookedList", bookedList);
		RequestDispatcher dispatcher = request.getRequestDispatcher("viewUserBookedEvent.jsp");
		dispatcher.forward(request, response);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		BookingEvent bookingEvent = new BookingEvent();

		bookingEvent.setBookingAddress(request.getParameter("bookingAddress"));
		bookingEvent.setTotalPeople(request.getParameter("totalPeople"));
		bookingEvent.setBookingDate(request.getParameter("bookingDate"));
		
		System.out.println(request.getParameter("bookingAddress"));
		System.out.println(request.getParameter("totalPeople"));
		System.out.println(request.getParameter("bookingDate"));
		
		boolean flag = eventService.addBookedEvent(bookingEvent);
		if (flag) {
			System.out.println("Event booked successfully");
			response.sendRedirect("BookEventServlet");
		} else {
			System.out.println("error in servlet");
		}
	}

}
