package com.cybage.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cybage.bean.Category;
import com.cybage.utility.JDBCUtility;

public class CategoryDAOImp implements CategoryDAO{

	@Override
	public boolean add(Category category) {
		int number=0;
		try (Connection connection = JDBCUtility.getConnection();) {
			
			String insertQuery = "insert into category (categoryname) values(?)";
			PreparedStatement preStmt = connection.prepareStatement(insertQuery);

			preStmt.setString(1, category.getCategoryName());
			
			number = preStmt.executeUpdate();
			System.out.println("Number of rows affected: " + number);
			if (number > 0) {
				System.out.println("Category inserted successfully");
			} else {
				System.out.println("Error in code");
			}
			
		} catch (Exception e) 
		{
			e.printStackTrace();
		} 
		finally 
		{
			JDBCUtility.closeConnection();
		}
		if (number >0) 
		{
			return true;
		} 
		else 
		{
			return false;
		}
}

	@Override
	public Category getCategoryById(int categoryId) {
		try (Connection connection = JDBCUtility.getConnection();) {
			
			String query = "select * from category where categoryId=?";
			PreparedStatement preStmt = connection.prepareStatement(query);
			preStmt.setInt(1, categoryId);

			ResultSet rs = preStmt.executeQuery();
		
			while (rs.next()) {
				
				Category category = new Category();
				
				category.setCategoryId(rs.getInt("categoryId"));
				category.setCategoryName(rs.getString("categoryName"));
				return category;
			}		
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		} 
		finally 
		{
			JDBCUtility.closeConnection();
		}
		return null;
	}

	@Override
	public List<Category> getAllCategory() {

		Connection connection = JDBCUtility.getConnection();
		List<Category> categoryList = new ArrayList<>();

		try (Statement statement = connection.createStatement()) {

			ResultSet rs = statement.executeQuery("select * from category");

			while (rs.next()) {

				Category category = new Category();

				category.setCategoryId(rs.getInt(1));
				category.setCategoryName(rs.getString(2));
				
				categoryList.add(category);	
			}
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		} 
		finally 
		{
			JDBCUtility.closeConnection();
		}
		return categoryList;

	}

	@Override
	public boolean deleteCategory(int categoryId) {
		
		Connection connection = JDBCUtility.getConnection();
		int number=0;
		try {
			String deleteQuery = "delete from category where categoryId=?";
			PreparedStatement preStmt = connection.prepareStatement(deleteQuery);

			preStmt.setInt(1, categoryId);

			number = preStmt.executeUpdate();
			System.out.println("Number of rows affected: " + number);
			if (number > 0) {
				System.out.println("Category deleted successfully");
			}

		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		} 
		finally 
		{
			JDBCUtility.closeConnection();
		}
		if (number >0) 
		{
			return true;
		} 
		else 
		{
			return false;
		}
	}

	@Override
	public boolean updateCategory(Category category) {
		int number=0;
		try (Connection connection = JDBCUtility.getConnection();) {

			String updateQuery = "update category set categoryName=? where categoryId=?";
			PreparedStatement preStmt = connection.prepareStatement(updateQuery);

			preStmt.setString(1, category.getCategoryName());
			preStmt.setInt(2, category.getCategoryId());

			number = preStmt.executeUpdate();
			System.out.println("Number of rows affected: " + number);
			
			if (number > 0) 
			{
				System.out.println("Category updated successfully");
			} 
			else 
			{
				System.out.println("Error in code");
			}

		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		} 
		finally 
		{
			JDBCUtility.closeConnection();
		}
		if (number >0) 
		{
			return true;
		} 
		else 
		{
			return false;
		}
	}

}