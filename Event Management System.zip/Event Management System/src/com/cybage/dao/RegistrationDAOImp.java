package com.cybage.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.catalina.connector.Response;

import com.cybage.bean.Category;
import com.cybage.bean.Registration;
import com.cybage.utility.JDBCUtility;

public class RegistrationDAOImp implements RegistrationDAO{

	@Override
	public boolean addUser(Registration registration) {
		
		int rowInsertCount = 0;
		String usernameCounter = "";
		String username = registration.getUsername();
		int userCount;
		boolean finalInsertStatus = false;
		
		try (Connection connection = JDBCUtility.getConnection();)
		{
			PreparedStatement st = connection.prepareStatement("select count(username) from users where username = '" + username + "'");
			ResultSet r1 = st.executeQuery();
			r1.next();
			userCount = r1.getInt(1);
			
			if (userCount == 0) {
			String insertQuery = "insert into users(ufname, ulname, username, uemail, upassword, uaddress, ucontact, role) values(?,?,?,?,?,?,?,?)";
			PreparedStatement preStmt = connection.prepareStatement(insertQuery);
			
			preStmt.setString(1, registration.getUfname());
			preStmt.setString(2, registration.getUlname());
			preStmt.setString(3, registration.getUsername());
			preStmt.setString(4, registration.getUemail());
			preStmt.setString(5, registration.getUpassword());
			preStmt.setString(6, registration.getUaddress());
			preStmt.setString(7, registration.getUcontact());
			preStmt.setString(8, registration.getRole());
			
			rowInsertCount = preStmt.executeUpdate();
			System.out.println("Number of rows affected: " + rowInsertCount);
			if (rowInsertCount > 0) {
				System.out.println("User inserted successfully");
			} else {
				System.out.println("Error in registration");
			}
			
		} 
		}catch (SQLException e) 
		{
			e.printStackTrace();
		} 
		finally 
		{
			JDBCUtility.closeConnection();
		}
		return finalInsertStatus;
		}

	@Override
	public Registration userLogin(Registration registration) {
		
		String userName = registration.getUsername();
		String password = registration.getUpassword();
		String role = registration.getRole();
		
		try (Connection connection = JDBCUtility.getConnection();)
		{
			String loginQuery = "insert into users(username=? and upassword=?)";
			
			PreparedStatement preStmt = connection.prepareStatement(loginQuery);
			
			preStmt.setString(1, userName);
			preStmt.setString(2, password);
			
			ResultSet rs = preStmt.executeQuery();
			
			while (rs.next()) {
				
				registration.setUid(rs.getInt(1));
				registration.setUfname(rs.getString(2));
				registration.setUlname(rs.getString(3));
				registration.setUsername(rs.getString(4));
				registration.setUemail(rs.getString(5));
				registration.setUpassword(rs.getString(6));
				registration.setUaddress(rs.getString(7));
				registration.setUcontact(rs.getString(8));
				registration.setRole(rs.getString(9));
			}
			System.out.println("Role in Implementation ="+registration.getRole());
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally 
		{
			JDBCUtility.closeConnection();
		}
		return registration;

	}

	@Override
	public List<Registration> getAllUsers() {
		Connection connection = JDBCUtility.getConnection();
		List<Registration> UserList = new ArrayList<>();
		
		try (Statement statement = connection.createStatement())
		{
			String Query = "select uid, ufname, ulname, username, uemail, upassword, uaddress, ucontact, role from users";
			
			ResultSet rs = statement.executeQuery(Query);
			
			while (rs.next()) {
				
				Registration Users = new Registration();
				
				Users.setUid(rs.getInt(1));
				Users.setUfname(rs.getString(2));
				Users.setUlname(rs.getString(3));
				Users.setUsername(rs.getString(4));
				Users.setUemail(rs.getString(5));
				Users.setUpassword(rs.getString(6));
				Users.setUaddress(rs.getString(7));
				Users.setUcontact(rs.getString(8));
				Users.setRole(rs.getString(9));
				
				UserList.add(Users);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtility.closeConnection();
		}
		return UserList;
	}	
}
