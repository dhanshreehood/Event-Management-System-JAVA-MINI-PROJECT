package com.cybage.dao;

import java.util.List;

import com.cybage.bean.Category;

public interface CategoryDAO {

	public boolean add(Category category);
	public Category getCategoryById(int categoryId);
	public List<Category> getAllCategory();
	public boolean deleteCategory(int categoryId);
	public boolean updateCategory(Category category);
}
