package com.cybage.dao;

import java.util.List;

import com.cybage.bean.AdminUser;

public interface AdminUserDAO {

	public List<AdminUser> getAllAdminUser();

}
