package com.cybage.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cybage.bean.User;
import com.cybage.utility.JDBCUtility;

public class AdminOrganizerDAOImp implements AdminOrganizerDAO{

	@Override
	public List<User> getAllAdminOrganizer() {
		Connection connection = JDBCUtility.getConnection();
		List<User> adminOrganizerList = new ArrayList<>();

		try (Statement stmt = connection.createStatement()) {

			ResultSet rs = stmt.executeQuery("select * from users where role=\'Event Organizer\'");

			while (rs.next()) {

				User adminOrganizer = new User();

				adminOrganizer.setUid(rs.getInt(1));
				adminOrganizer.setUfname(rs.getString(2));
				adminOrganizer.setUlname(rs.getString(3));
				adminOrganizer.setUsername(rs.getString(4));
				adminOrganizer.setUemail(rs.getString(5));
				adminOrganizer.setUpassword(rs.getString(6));
				adminOrganizer.setUaddress(rs.getString(7));
				adminOrganizer.setUcontact(rs.getString(8));
				
				adminOrganizerList.add(adminOrganizer);

			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JDBCUtility.closeConnection();
		}
		return adminOrganizerList;

	}

}
