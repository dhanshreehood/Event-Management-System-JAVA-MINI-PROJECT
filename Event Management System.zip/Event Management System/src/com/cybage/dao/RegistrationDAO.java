package com.cybage.dao;

import java.util.List;
import com.cybage.bean.Registration;

public interface RegistrationDAO {

	public boolean addUser(Registration registration);
	public Registration userLogin(Registration registration);
	public List<Registration>getAllUsers();	
	
}
