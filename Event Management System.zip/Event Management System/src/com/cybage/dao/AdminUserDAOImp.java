package com.cybage.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cybage.bean.AdminUser;
import com.cybage.utility.JDBCUtility;

public class AdminUserDAOImp implements AdminUserDAO{

	@Override
	public List<AdminUser> getAllAdminUser() {
		Connection connection = JDBCUtility.getConnection();
		List<AdminUser> adminUserList = new ArrayList<>();

		try (Statement stmt = connection.createStatement()) {

			ResultSet rs = stmt.executeQuery(" select * from users where role=\'User\'");

			while (rs.next()) {

				AdminUser adminUser = new AdminUser();

				adminUser.setUid(rs.getInt(1));
				adminUser.setUsername(rs.getString(2));
				adminUser.setUemail(rs.getString(3));
				adminUser.setUpassword(rs.getString(4));
				adminUser.setUaddress(rs.getString(5));
				adminUser.setUcontact(rs.getString(6));

				adminUserList.add(adminUser);

			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JDBCUtility.closeConnection();
		}
		return adminUserList;

	}

}
