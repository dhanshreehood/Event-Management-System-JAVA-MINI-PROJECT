package com.cybage.dao;

import java.util.List;

import com.cybage.bean.User;

public interface AdminOrganizerDAO {

	public List<User> getAllAdminOrganizer();
}
