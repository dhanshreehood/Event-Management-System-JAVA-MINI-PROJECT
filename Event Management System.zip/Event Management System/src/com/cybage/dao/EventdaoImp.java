package com.cybage.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cybage.bean.BookingEvent;
import com.cybage.bean.Category;
import com.cybage.bean.Event;
import com.cybage.bean.User;
import com.cybage.utility.JDBCUtility;

public class EventdaoImp implements Eventdao {
/* Add */
	
	public boolean add(Event event) {
		int number=0;
		try (Connection connection = JDBCUtility.getConnection();) {

			
			String insertQuery = "insert into event (eventName, eventCategory,eventDescription,eventPrice) values(?,?,?,?)";
			PreparedStatement preStmt = connection.prepareStatement(insertQuery);

			preStmt.setString(1, event.getEventName());
			preStmt.setString(2, event.getEventCategory());
			preStmt.setString(3, event.getEventDescription());
			preStmt.setString(4, event.getEventPrice());

			number = preStmt.executeUpdate();
			System.out.println("Number of rows affected: " + number);
			if (number > 0) {
				System.out.println("Event inserted successfully");
			} else {
				System.out.println("error in DAO");
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtility.closeConnection();
		}
		if (number >0) {
			return true;
		} else {
			return false;
		}
		
	}

	
	
	@Override
	public Event getEventById(int eventId) {
		
		try (Connection connection = JDBCUtility.getConnection();) {

			
			String query = "select * from event where eventId=?";
			PreparedStatement preStmt = connection.prepareStatement(query);
			preStmt.setInt(1, eventId);
			

			ResultSet rs = preStmt.executeQuery();
			
			while (rs.next()) {
			
				Event event = new Event();
			
				event.setEventId(rs.getInt("eventId"));			
				event.setEventName(rs.getString("eventName"));
		        event.setEventCategory(rs.getString("eventCategory"));
		        event.setEventDescription(rs.getString("eventDescription"));
			    event.setEventPrice(rs.getString("eventPrice"));
		
				return event;
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtility.closeConnection();
		}
		return null;
	
	}

	@Override
	public List<Event> getAllEvent() {
		Connection connection = JDBCUtility.getConnection();
		List<Event> eventList = new ArrayList<>();

		try (Statement stmt = connection.createStatement()) {

			ResultSet rs = stmt.executeQuery("select * from event");

			while (rs.next()) {

				Event event = new Event();

				event.setEventId(rs.getInt(1));
				event.setEventName(rs.getString(2));
				event.setEventCategory(rs.getString(3));
				event.setEventDescription(rs.getString(4));
				event.setEventPrice(rs.getString(5));

				eventList.add(event);
	
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JDBCUtility.closeConnection();
		}
		return eventList;

	}

	@Override
	public boolean EventDelete(int eventId) {
		Connection connection = JDBCUtility.getConnection();
		int number=0;
		try {
			
			String deleteQuery = "delete from event where eventId=?";
			PreparedStatement preStmt = connection.prepareStatement(deleteQuery);

			preStmt.setInt(1, eventId);

			 number = preStmt.executeUpdate();
			System.out.println("Number of rows affected: " + number);
			if (number > 0) {
				System.out.println("event deleted successfully");
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JDBCUtility.closeConnection();
		}
		if (number >0) {
			return true;
		} else {
			return false;
		}
	}

	public boolean EventEdit(Event event) {
		int number=0;
		try (Connection connection = JDBCUtility.getConnection();) {

		
			String updateQuery = "update event set eventName=?, eventCategory=?, eventDescription=?, eventPrice=? where eventId=?";
			PreparedStatement preStmt = connection.prepareStatement(updateQuery);

			preStmt.setString(1, event.getEventName());
			preStmt.setString(2, event.getEventCategory());
			preStmt.setString(3, event.getEventDescription());
			preStmt.setString(4, event.getEventPrice());
			preStmt.setInt(5, event.getEventId());

			number = preStmt.executeUpdate();
			System.out.println("Number of rows affected: " + number);
			if (number > 0) {
				System.out.println("event edited successfully");
			} else {
				System.out.println("error");
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtility.closeConnection();
		}
		if (number >0) {
			return true;
		} else {
			return false;
		}
	}



	@Override
	public String authenticateUser(User user) {
		
	         String username = user.getUsername(); //Assign user entered values to temporary variables.
	         String password = user.getUpassword();
	         String role = user.getRole();

	         String userNameDB = "";
	         String passwordDB = "";
	         String roleDB = "";
	 
	         try(Connection connection = JDBCUtility.getConnection();)
	         {
	             //statement = con.createStatement(); //Statement is used to write queries. Read more about it.
	             //resultSet = statement.executeQuery("select username, password from user"); //the table name is user and username,password are columns. Fetching all the records and storing in a resultSet.
	        	 String query = "select username, upassword, role from users";
	 			 PreparedStatement preStmt = connection.prepareStatement(query);

				ResultSet rs = preStmt.executeQuery();

	             while(rs.next()) // Until next row is present otherwise it return false
	             {
	              userNameDB = rs.getString("username"); //fetch the values present in database
	              passwordDB = rs.getString("upassword");
	              roleDB = rs.getString("role");

	             if(username.equals(userNameDB) && password.equals(passwordDB) && roleDB.equals("User"))
	             {
	                  return "USER"; //is user is present as a role with username and password validation it will return "USER".
	             }
	             else if(username.equals(userNameDB) && password.equals(passwordDB) && roleDB.equals("Event Organizer")) {
	            	 return "EVENT_ORGANIZER";//is Event Organizer is present as a role with username and password validation it will return "EVENT_ORGANIZER".
	             }
	             }
	             }
	             catch(SQLException e)
	             {
	                e.printStackTrace();
	             }finally {
	     			JDBCUtility.closeConnection();
	     		}
	             return "Invalid user credentials"; // Return appropriate message in case of failure
	         	}



	@Override
	public boolean addBookedEvent(BookingEvent bookingEvent) {
		int number=0;
		try (Connection connection = JDBCUtility.getConnection();) {

			
			String insertQuery = "insert into bookingevent (bookingAddress, totalPeople, bookingDate) values(?,?,?)";
			PreparedStatement preStmt = connection.prepareStatement(insertQuery);

			preStmt.setString(1, bookingEvent.getBookingAddress());
			preStmt.setString(2, bookingEvent.getTotalPeople());
			preStmt.setString(3, bookingEvent.getBookingDate());

			number = preStmt.executeUpdate();
			System.out.println("Number of rows affected: " + number);
			if (number > 0) {
				System.out.println("Event booked successfully");
			} else {
				System.out.println("error in DAO");
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCUtility.closeConnection();
		}
		if (number >0) {
			return true;
		} else {
			return false;
		}
	}



	@Override
	public List<BookingEvent> getAllBookedEvent() {
		Connection connection = JDBCUtility.getConnection();
		List<BookingEvent> bookingList = new ArrayList<>();

		try (Statement statement = connection.createStatement()) {

			ResultSet rs = statement.executeQuery("select * from bookingevent");

			while (rs.next()) {

				BookingEvent bookingEvent = new BookingEvent();

				bookingEvent.setBookingId(rs.getInt(1));
				bookingEvent.setBookingAddress(rs.getString(2));
				bookingEvent.setTotalPeople(rs.getString(3));
				bookingEvent.setBookingDate(rs.getString(4));
				
				bookingList.add(bookingEvent);	
			}
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		} 
		finally 
		{
			JDBCUtility.closeConnection();
		}
		return bookingList;
	}



	@Override
	public boolean deleteBookedEvent(int bookingId) {
		Connection connection = JDBCUtility.getConnection();
		int number=0;
		try {
			String deleteQuery = "delete from bookingevent where bookingId=?";
			PreparedStatement preStmt = connection.prepareStatement(deleteQuery);

			preStmt.setInt(1, bookingId);

			number = preStmt.executeUpdate();
			System.out.println("Number of rows affected: " + number);
			if (number > 0) {
				System.out.println("Booked event deleted successfully");
			}

		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		} 
		finally 
		{
			JDBCUtility.closeConnection();
		}
		if (number >0) 
		{
			return true;
		} 
		else 
		{
			return false;
		}
	}
	}

	
	
	

